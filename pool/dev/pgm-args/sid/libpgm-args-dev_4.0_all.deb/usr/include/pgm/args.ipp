////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2026 Dimitry Ishenko
// Contact: dimitry (dot) ishenko (at) (gee) mail (dot) com
//
// Distributed under the GNU GPL license. See the LICENSE.md file for details.

////////////////////////////////////////////////////////////////////////////////
#pragma once

#include "args.hpp"

#include <algorithm>
#include <charconv> // std::from_chars
#include <deque>
#include <format>
#include <fstream>
#include <optional>
#include <ranges>
#include <sstream>
#include <tuple>
#include <vector>
#include <type_traits>

////////////////////////////////////////////////////////////////////////////////
namespace pgm
{

////////////////////////////////////////////////////////////////////////////////
namespace
{

namespace ranges = std::ranges;

constexpr bool iequals(std::string_view l, std::string_view r)
{
    auto lower = [](char c) { return c >= 'A' && c <= 'Z' ? char(c - 'A' + 'a') : c; };
    return ranges::equal(l, r, {}, lower, lower);
}

constexpr bool is_alnum(char c) {
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}
constexpr bool is_dash_alnum(char c) { return c == '-' || is_alnum(c); }
constexpr bool is_graph(char c) { return c >= '!' && c <= '~'; }

constexpr bool is_valid_short_option(std::string_view s) {
    return s.size() == 2 && s[0] == '-' && is_alnum(s[1]);
}

constexpr bool is_valid_long_option(std::string_view s) {
    return s.size() > 2 && s[0] == '-' && s[1] == '-' && s[2] != '-' && ranges::all_of(s, is_dash_alnum);
}

constexpr bool is_valid_name(std::string_view s) {
    return s.size() > 0 && s[0] != '-' && ranges::all_of(s, is_graph);
}

constexpr bool is_not_option(std::string_view s) { return s.empty() || s == "-" || s[0] != '-'; }

////////////////////////////////////////////////////////////////////////////////
inline auto make_option(std::string s1, std::string s2, std::string s3, pgm::spec spec, std::string desc)
{
    return option{ std::move(s1), std::move(s2), std::move(s3), std::move(desc),
        !!(spec & req), !!(spec & mul), !!(spec & optval), {}
    };
}

inline auto make_param(std::string s, pgm::spec spec, std::string desc) {
    return param{ std::move(s), std::move(desc), !!(spec & opt), !!(spec & mul), {} };
}

inline auto pop(std::deque<std::string>& q)
{
    auto el = std::move(q.front());
    q.pop_front();
    return el;
}

}

////////////////////////////////////////////////////////////////////////////////
template<typename V>
expected<V> convert(std::string_view s)
{
    static_assert(std::is_arithmetic_v<V>, "Unsupported value type");

    if constexpr (std::is_same_v<V, bool>)
    {
        if (iequals(s,  "true") || iequals(s, "yes") || iequals(s,  "on") || s == "1") return true;
        if (iequals(s, "false") || iequals(s,  "no") || iequals(s, "off") || s == "0") return false;
        return unexpected("invalid boolean value '" + std::string{s} + "'");
    }
    else
    {
        auto digits = s;
        if (digits.starts_with('+') && !digits.starts_with("+-")) digits.remove_prefix(1);

        V val;
        auto [end, ec] = std::from_chars(digits.data(), digits.data() + digits.size(), val);
        if (ec == std::errc{} && end == digits.data() + digits.size()) return val;

        auto msg = "invalid value '" + std::string{s} + "'";
        if (ec == std::errc::result_out_of_range) msg += " - out of range";
        return unexpected(std::move(msg));
    }
}

template<typename V>
decltype(auto) argval::value(std::size_t n) const
{
    using U = std::remove_cvref_t<V>;

    if (n >= data_.size())
        throw std::out_of_range{name_ + ": bad value index " + std::to_string(n)};

    if constexpr (std::is_same_v<U, std::string>)
        return data_[n]; // const std::string&
    else if (auto ev = convert<U>(data_[n]))
        return auto(ev.value());
    else throw invalid_argument{name_ + ": " + ev.error()};
}

template<typename V>
auto argval::value_or(std::size_t n, V def) const
{
    using U = std::remove_cvref_t<V>;

    if constexpr (std::is_convertible_v<U, std::string_view>)
        return n < count() ? data_[n] : std::string{std::move(def)};
    else return n < count() ? value<U>(n) : std::move(def);
}

template<typename V>
decltype(auto) argval::values() const
{
    using U = std::remove_cvref_t<V>;

    if constexpr (!std::is_same_v<U, std::string>)
    {
        std::vector<U> data;
        for (std::size_t i = 0; i < count(); ++i) data.push_back(value<U>(i));
        return data;
    }
    else return (data_); // const std::vector<std::string>&
}

////////////////////////////////////////////////////////////////////////////////
inline arg::arg(std::string s, pgm::spec spec, std::string desc)
{
    if (is_valid_short_option(s))
        val_ = make_option(std::move(s), {}, {}, spec, std::move(desc));

    else if (is_valid_long_option(s))
        val_ = make_option({}, std::move(s), {}, spec, std::move(desc));

    else if (is_valid_name(s))
        val_ = make_param(std::move(s), spec, std::move(desc));

    else throw invalid_definition{"bad option or param name '" + s + "'"};
}

////////////////////////////////////////////////////////////////////////////////
inline arg::arg(std::string s1, std::string s2, pgm::spec spec, std::string desc)
{
    if (is_valid_short_option(s1))
    {
        if (is_valid_long_option(s2))
            val_ = make_option(std::move(s1), std::move(s2), {}, spec, std::move(desc));

        else if (is_valid_name(s2))
            val_ = make_option(std::move(s1), {}, std::move(s2), spec, std::move(desc));

        else throw invalid_definition{"bad long option or option value name '" + s2 + "'"};
    }
    else if (is_valid_long_option(s1))
    {
        if (is_valid_name(s2))
            val_ = make_option({}, std::move(s1), std::move(s2), spec, std::move(desc));

        else throw invalid_definition{"bad option value name '" + s2 + "'"};
    }
    else throw invalid_definition{"bad short or long option name '" + s1 + "'"};
}

////////////////////////////////////////////////////////////////////////////////
inline arg::arg(std::string s1, std::string s2, std::string s3, pgm::spec spec, std::string desc)
{
    if (!is_valid_short_option(s1))
        throw invalid_definition{"bad short option name '" + s1 + "'"};

    else if (!is_valid_long_option(s2))
        throw invalid_definition{"bad long option name '" + s2 + "'"};

    else if (!is_valid_name(s3))
        throw invalid_definition{"bad option value name '" + s3 + "'"};

    else val_ = make_option(std::move(s1), std::move(s2), std::move(s3), spec, std::move(desc));
}

////////////////////////////////////////////////////////////////////////////////
inline void args::reset() noexcept
{
    for (auto& o : options_) o.values.clear();
    for (auto& p : params_)  p.values.clear();
}

////////////////////////////////////////////////////////////////////////////////
inline void args::add(arg a)
{
    if (a.is_option())
        add_option(std::move(a.to_option()));
    else if (a.is_param())
        add_param(std::move(a.to_param()));
    else throw invalid_definition{"neither option nor param"};
}

////////////////////////////////////////////////////////////////////////////////
inline void args::add_option(option o)
{
    if (!o.short_name.empty()
        && ranges::find(options_, o.short_name, &option::short_name) != options_.end())
            throw invalid_definition{"duplicate option '" + o.short_name + "'"};

    if (!o.long_name.empty()
        && ranges::find(options_, o.long_name, &option::long_name) != options_.end())
            throw invalid_definition{"duplicate option '" + o.long_name + "'"};

    o.values.name_ = name(o);
    options_.push_back(std::move(o));
}

////////////////////////////////////////////////////////////////////////////////
inline void args::add_param(param p)
{
    if (ranges::find(params_, p.name, &param::name) != params_.end())
        throw invalid_definition{"duplicate " + name(p)};

    if (p.mul && ranges::any_of(params_, &param::mul))
        throw invalid_definition{"more than one multi-value " + name(p)};

    p.values.name_ = name(p);
    params_.push_back(std::move(p));
}

////////////////////////////////////////////////////////////////////////////////
inline argval const& args::operator[](std::string_view name) const
{
    if (!name.empty())
    {
        for (auto&& el : options_)
            if (el.short_name == name || el.long_name == name) return el.values;

        for (auto&& el : params_) if (el.name == name) return el.values;
    }
    throw invalid_argument{"unrecognized option or param '" + std::string{name} + "'"};
}

////////////////////////////////////////////////////////////////////////////////
inline std::string args::name(const option& o)
{
    auto name = o.short_name.empty() ? o.long_name
        : o.long_name.empty() ? o.short_name
        : o.short_name + ", " + o.long_name;
    return "option '" + name + "'";
}
inline std::string args::name(const param& p) { return "param '" + p.name + "'"; }

////////////////////////////////////////////////////////////////////////////////
inline void args::parse(const std::filesystem::path& path)
{
    std::ifstream in{path};
    if (!in) throw std::runtime_error{"cannot open '" + path.string() + "'"};

    struct invalid { std::string why; };
    struct missing { std::string why; };

    std::vector<bool> seen(options_.size());

    std::string line;
    for (int n = 1; std::getline(in, line); ++n)
    try
    {
        std::string name;
        std::optional<std::string> value;

        std::istringstream is{line};

        if ((is >> std::ws).eof()) continue;
        is >> name;
        if (name.starts_with('#') || (name.starts_with('[') && name.ends_with(']'))) continue;

        if (!(is >> std::ws).eof())
        {
            std::string word;
            is >> word;

            if (!word.starts_with('#'))
            {
                if (word != "=") throw invalid{"missing '='"};
                if ((is >> std::ws).eof()) throw missing{"missing value"};

                char ch = is.peek();
                if (ch == '"')
                {
                    if (!(is >> std::quoted(word))) throw invalid{"unclosed quote"};
                }
                else if (ch != '#') is >> word;
                else throw missing{"missing value"};

                value = std::move(word);

                if (!(is >> std::ws).eof())
                {
                    is >> word;
                    if (!word.starts_with('#')) throw invalid{"garbage at end"};
                }
            }
        }

        // find matching definition
        auto match = ranges::find_if(options_,
            [name = "--" + name](auto&& o){ return name == o.long_name; }
        );
        if (match == options_.end())
            throw invalid{"unrecognized option '" + name + "'"};

        else if (match->valname.empty()) // doesn't take values
        {
            // ...but we have one
            if (value) throw invalid{"'" + name + "' doesn't take values"};
            value = ""; // indicate presence
        }
        else // may take a value
        {
            // ...but we don't have one
            if (!value)
            {
                if (!match->optval) throw missing{"'" + name + "' requires a value"};
                value = ""; // indicate presence
            }
        }

        if (!match->mul)
        {
            auto idx = match - options_.begin();
            if (!seen[idx])
            {
                seen[idx] = true;
                match->values.clear();
            }
            else throw invalid{"duplicate option '" + name + "'"};
        }

        match->values.add(std::move(*value));
    }
    catch (const invalid& e)
    {
        throw invalid_argument{path.string() + ":" + std::to_string(n) + " - " + e.why};
    }
    catch (const missing& e)
    {
        throw missing_argument{path.string() + ":" + std::to_string(n) + " - " + e.why};
    }
}

////////////////////////////////////////////////////////////////////////////////
inline void args::parse(int argc, char* argv[])
{
    std::deque<std::string> args;
    for (auto n = 1; n < argc; ++n) args.emplace_back(argv[n]);

    bool had_token = false; // end-of-options token ("--")
    std::deque<std::string> store; // for params

    std::vector<bool> seen(options_.size());

    while (args.size())
    {
        auto arg = pop(args);

        if (had_token || is_not_option(arg)) // either "" or "-" or "[^-].+"
            store.push_back(std::move(arg));

        else if (arg == "--") // end-of-options token
            had_token = true;

        else // an option ("-.+")
        {
            std::string name;
            std::optional<std::string> value;

            if (arg[1] == '-') // long option ("--.+")
            {
                if (auto p = arg.find('=', 2); p != arg.npos) // ...with value ("--[^=]+=.?")
                {
                    name = arg.substr(0, p);
                    value = arg.substr(p + 1);
                }
                else name = arg; // ...without value ("--[^=]+")
            }
            else // short option (-[^-].?)
            {
                name = arg.substr(0, 2);
                if (arg.size() > 2) value = arg.substr(2); // ...with value ("-[^-].+")
            }

            // find matching definition
            auto match = ranges::find_if(options_,
                [&](auto&& o){ return name == o.short_name || name == o.long_name; }
            );
            if (match == options_.end())
                throw invalid_argument{"unrecognized option '" + name + "'"};

            else if (match->valname.empty()) // doesn't take values
            {
                if (value) // ...but we have one
                {
                    if (name.size() == 2) // short option
                    {
                        // this might be a group of short options (eg, -abc),
                        // push the rest back into the queue
                        args.push_front("-" + *value);
                    }
                    else throw invalid_argument{"'" + name + "' doesn't take values"};
                }
                value = ""; // indicate presence
            }
            else if (match->optval) // value is optional
            {
                if (!value) // ...and we don't have one
                {
                    // take the next arg, if it's not an option
                    if (args.size() && is_not_option(args[0]))
                        value = pop(args);
                    else value = ""; // or indicate presence
                }
            }
            else // requires a value
            {
                if (!value) // ...but we don't have one
                {
                    // take the next arg unless it's the end-of-options token
                    if (args.size() && args[0] != "--")
                        value = pop(args);
                    else throw missing_argument{"'" + name + "' requires a value"};
                }
            }

            if (!match->mul)
            {
                auto idx = match - options_.begin();
                if (!seen[idx])
                {
                    seen[idx] = true;
                    match->values.clear();
                }
                else throw invalid_argument{"duplicate option '" + name + "'"};
            }

            match->values.add(std::move(*value));
        }
    }

    // check required options
    for (auto&& o : options_)
        if (o.req && o.values.empty())
            throw missing_argument{name(o) + " is required"};

    // # of non-opt params to fill
    auto need = static_cast<std::size_t>( ranges::count(params_, false, &param::opt) );

    auto remain = params_.size();
    for (auto&& p : params_)
    {
        --remain;

        if (p.opt)
        {
            // can we spare a value for this param?
            if (!(store.size() > need)) continue;
        }
        else --need;

        if (store.size())
        {
            // munch as many values as we can
            do p.values.add(pop(store));
            while (p.mul && store.size() > remain);
        }
        else throw missing_argument{name(p) + " is required"};
    }

    if (store.size()) throw invalid_argument{"extra param '" + store[0] + "'"};
}

////////////////////////////////////////////////////////////////////////////////
inline std::string args::usage(std::string_view program, std::string_view preamble,
    std::string_view prologue, std::string_view epilogue) const
{
    std::size_t width0 = 0;
    std::vector<std::tuple<std::string, std::string>> rows;

    ////////////////////
    if (preamble.size())
    {
        rows.emplace_back(preamble, "");
        rows.emplace_back("", "");
    }

    ////////////////////
    auto col0 = "Usage: " + std::string(program);
    if (options_.size()) col0 += " [option]...";
    for (auto&& p : params_)
    {
        col0 += (p.opt ? " [" : " <") + p.name + (p.opt ? "]" : ">");
        if (p.mul) col0 += "...";
    }
    rows.emplace_back(std::move(col0), "");

    ////////////////////
    if (prologue.size())
    {
        rows.emplace_back("", "");
        rows.emplace_back(prologue, "");
    }

    ////////////////////
    if (options_.size())
    {
        rows.emplace_back("", "");
        rows.emplace_back("Options:", "");

        bool fill = ranges::any_of(options_, [](auto&& s){ return s.size(); }, &option::short_name);
        for (auto&& o : options_)
        {
            std::string col0;
            if (o.short_name.size())
            {
                col0 += o.short_name;                           // "-o"
                if (o.long_name.size())
                {
                    col0 += ", " + o.long_name;                 // "-o, --opt"
                    if (o.valname.size()) col0 += "=";          // "-o, --opt="
                }
                else if (o.valname.size()) col0 += " ";         // "-o "
            }
            else
            {
                col0 += (fill ? "    " : "") + o.long_name;     // "    --opt"
                if (o.valname.size()) col0 += "=";              // "    --opt="
            }

            if (!o.valname.empty())
            {
                if (o.optval) col0 += "[" + o.valname + "]";    // ...[val]
                else          col0 += "<" + o.valname + ">";    // ...<val>
            }

            width0 = std::max(col0.size(), width0);

            auto& desc = o.description; // ref
            for (std::size_t p0 = 0, p1 = 0; p1 != desc.npos; p0 = p1 + 1)
            {
                p1 = desc.find('\n', p0);
                rows.emplace_back(std::move(col0), desc.substr(p0, p1 - p0));
                col0.clear();
            }
        }
    }

    ////////////////////
    if (params_.size())
    {
        rows.emplace_back("", "");
        rows.emplace_back("Parameters:", "");

        for (auto&& p : params_)
        {
            std::string col0 = p.name; // copy

            width0 = std::max(col0.size(), width0);

            auto& desc = p.description; // ref
            for (std::size_t p0 = 0, p1 = 0; p1 != desc.npos; p0 = p1 + 1)
            {
                p1 = desc.find('\n', p0);
                rows.emplace_back(std::move(col0), desc.substr(p0, p1 - p0));
                col0.clear();
            }
        }
    }

    ////////////////////
    if (epilogue.size())
    {
        rows.emplace_back("", "");
        rows.emplace_back(epilogue, "");
    }

    ////////////////////
    std::string usage;
    for (auto&& [col0, col1] : rows)
    {
        if (col1.empty()) usage += std::format("{}\n", col0);
        else usage += std::format("{:<{}}    {}\n", col0, width0, col1);
    }
    usage.pop_back();

    return usage;
}

////////////////////////////////////////////////////////////////////////////////
}
