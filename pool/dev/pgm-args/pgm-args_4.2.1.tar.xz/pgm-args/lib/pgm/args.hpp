////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2018-2026 Dimitry Ishenko
// Contact: dimitry (dot) ishenko (at) (gee) mail (dot) com
//
// Distributed under the GNU GPL license. See the LICENSE.md file for details.

////////////////////////////////////////////////////////////////////////////////
#pragma once

#include <expected>
#include <filesystem>
#include <initializer_list>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

////////////////////////////////////////////////////////////////////////////////
namespace pgm
{

template<typename V>
using expected = std::expected<V, std::string>;
using std::unexpected;

template<typename V>
expected<V> convert(std::string_view);

////////////////////////////////////////////////////////////////////////////////
// option/param spec
enum spec
{
    req    = 1, // required option
    mul    = 2, // option/param can be specified multiple times
    optval = 4, // option value is optional
    opt    = 8, // optional param
};

constexpr auto operator|(spec lhs, spec rhs) noexcept {
    return static_cast<spec>(static_cast<int>(lhs) | static_cast<int>(rhs));
}

////////////////////////////////////////////////////////////////////////////////
// option/param values
struct argval
{
    auto count() const noexcept { return data_.size(); }
    auto empty() const noexcept { return data_.empty(); }

    explicit operator bool() const noexcept { return !empty(); }

    template<typename V = std::string>
    decltype(auto) value(std::size_t n = 0) const;

    template<typename V>
    auto value_or(std::size_t n, V def) const;
    template<typename V>
    auto value_or(V def) const { return value_or(0, std::move(def)); }

    template<typename V = std::string>
    decltype(auto) values() const;

private:
    std::string name_;
    std::vector<std::string> data_;

    friend struct args;
    void clear() noexcept { data_.clear(); }
    void add(std::string val) { data_.push_back(std::move(val)); }
};

////////////////////////////////////////////////////////////////////////////////
struct option
{
    std::string short_name;  // short option name
    std::string long_name;   // long option name
    std::string valname;     // name of the option value; eg, --opt-name=<value>
    std::string description; // description

    bool req = false;        // required option
    bool mul = false;        // can be specified multiple times
    bool optval = false;     // option value is optional

    argval values;           // parsed option values
};

////////////////////////////////////////////////////////////////////////////////
struct param
{
    std::string name;        // param name
    std::string description; // description

    bool opt = false;        // optional param
    bool mul = false;        // can be specified multiple times

    argval values;           // parsed param values
};

////////////////////////////////////////////////////////////////////////////////
struct arg
{
    // `s` can be a short option name, a long option name or a param name
    arg(std::string s, std::string description) :
        arg{std::move(s), spec{}, std::move(description)}
    { }
    arg(std::string s, spec, std::string description);

    // `s1` can be either a short option name or a long option name
    // if `s1` is a short option name, `s2` can be a long option name or an option value name
    // if `s1` is a long  option name, `s2` is an option value name
    arg(std::string s1, std::string s2, std::string description) :
        arg{std::move(s1), std::move(s2), spec{}, std::move(description)}
    { }
    arg(std::string s1, std::string s2, spec, std::string description);

    // `s1` is a short option name, `s2` is a long option name and `s3` is an option value name
    arg(std::string s1, std::string s2, std::string s3, std::string description) :
        arg{std::move(s1), std::move(s2), std::move(s3), spec{}, std::move(description)}
    { }
    arg(std::string s1, std::string s2, std::string s3, spec, std::string description);

    auto is_option() const noexcept { return std::holds_alternative<option>(val_); }
    auto is_param() const noexcept { return std::holds_alternative<param>(val_); }

    auto& to_option() { return std::get<option>(val_); }
    auto& to_param() { return std::get<param>(val_); }

private:
    std::variant<option, param> val_;
};

////////////////////////////////////////////////////////////////////////////////
struct args
{
    args() noexcept = default;
    explicit args(std::initializer_list<arg> il) { for (auto&& v : il) add(v); }

    void reset() noexcept;

    void add(arg);
    void add(auto&&... args) { add(arg{ std::forward<decltype (args)>(args)... }); }

    argval const& operator[](std::string_view) const;

    void parse(const std::filesystem::path&);
    void parse(int argc, char* argv[]);

    std::string usage(std::string_view program, std::string_view preamble = {},
        std::string_view prologue = {}, std::string_view epilogue = {}) const;

private:
    std::vector<option> options_;
    std::vector<param> params_;

    void add_option(option);
    void add_param(param);

    static std::string name(const option&);
    static std::string name(const param&);
};

////////////////////////////////////////////////////////////////////////////////
struct argument_exception : std::invalid_argument
{
    argument_exception(std::string_view what, std::string_view why) :
        std::invalid_argument{std::string{what} + ": " + std::string{why} + "."}
    { }
};

struct invalid_definition : argument_exception
{
    invalid_definition(std::string_view why) :
        argument_exception{"Invalid definition", why}
    { }
};

struct invalid_argument : argument_exception
{
    invalid_argument(std::string_view why) :
        argument_exception{"Invalid argument", why}
    { }
};

struct missing_argument : argument_exception
{
    missing_argument(std::string_view why) :
        argument_exception{"Missing argument", why}
    { }
};

////////////////////////////////////////////////////////////////////////////////
}

#include "args.ipp"
