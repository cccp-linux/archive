import argparse, signal, sys
from pathlib import Path

from . import __version__
from .create import create
from .watch  import watch

def stop(signum, _):
    print("Received signal", signum, "- exiting");
    sys.exit(0)

signal.signal(signal.SIGINT, stop)
signal.signal(signal.SIGTERM, stop)

def parse_suites(value):
    suites = {}
    for suite in value.split(","):
        if suite:
            suite, sep, tag  = suite.partition("~")
            tag = "~" + tag if sep else None

            suite, sep, code = suite.partition(":")
            code = code if sep else suite

            suites[suite] = (code, tag)
    return suites

def parse_arches(value):
    arches = {} # using dict instead of set to preserve order
    for arch in value.split(","):
        if arch: arches[arch] = arch
    return arches

def main():
    parser = argparse.ArgumentParser(description="Micro build daemon")
    parser.add_argument(
        "-d", "--directory", type=Path, metavar="path", default=Path.cwd(),
        help="repository path (default: current dir)"
    )
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s v{__version__}")

    ####################
    subparsers = parser.add_subparsers(dest="command")

    create_parser = subparsers.add_parser("create", help="create repository structure",
        formatter_class=argparse.RawTextHelpFormatter
    )
    create_parser.add_argument(
        "-o", "--origin", metavar="name", default="Deep Thought",
        help="repository origin name (default: Deep Thought)"
    )
    create_parser.add_argument(
        "-s", "--suites", type=parse_suites, metavar="suites", default=None,
        help="comma-separated list of suites (default: current suite)"
    )
    create_parser.add_argument(
        "-a", "--arches", type=parse_arches, metavar="arches", default=None,
        help="comma-separated list of architectures (default: current arch)"
    )
    create_parser.add_argument(
        "-k", "--sign-key", metavar="key", default=None,
        help="GPG signing key (optional)"
    )
    create_parser.add_argument(
        "-p", "--pull-from", metavar="name", default=None,
        help="suite that all others will pull from (optional)"
    )
    create_parser.epilog="""\
suite syntax:
  suite[~tag]           same Suite and Codename (e.g. resolute, noble~ubuntu22.04)
  suite:codename[~tag]  distinct Suite and Codename (e.g. unstable:sid,
                        stable:trixie~deb13)
  debian                current Debian stable, testing & unstable releases
  ubuntu                supported Ubuntu releases

tags:
  tags are appended to binary package versions to avoid name collisions when
  the same source package is uploaded to more than one suite
"""

    subparsers.add_parser("watch", help="watch repository for changes")

    ####################
    args = parser.parse_args()

    command = args.command or "watch"
    basedir = args.directory.resolve()

    if command == "create":
        create(basedir, args.origin, args.suites, args.arches, args.sign_key, args.pull_from)
    elif command == "watch":
        watch(basedir)

if __name__ == "__main__": main()
