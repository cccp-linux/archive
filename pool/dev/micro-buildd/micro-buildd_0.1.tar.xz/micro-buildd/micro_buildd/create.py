from debian.deb822 import Deb822
from subprocess import check_output, run

def get_distro_data(distro):
    cmd = [distro + "-distro-info", "--supported"]
    codes = check_output(cmd, text=True).splitlines()
    names = check_output(cmd + ["--fullname"], text=True).splitlines()
    releases = check_output(cmd + ["--release"], text=True).splitlines()

    data = {}
    for code, name, release in zip(codes, names, releases):
        vers = release.partition(" ")[0]
        data[code] = (name, vers)
    return data

def get_debian_code(alias):
    return check_output(["debian-distro-info", "--" + alias], text=True).strip()

def get_current_suite():
    return check_output(["lsb_release", "-cs"], text=True).strip()

def get_current_arch():
    return check_output(["dpkg", "--print-architecture"], text=True).strip()

def create_distros(basedir, origin, suites, arches, sign_key=None, pull_from=None):
    paras = []
    for suite, (code, tag, name) in suites.items():
        para = Deb822()
        para["Origin"     ] = origin
        para["Label"      ] = origin + ' ' + code.capitalize()
        para["Suite"      ] = suite
        para["Codename"   ] = code
        para["Architectures"] = "source " + ' '.join(arches.keys())
        para["Components" ] = "main"
        para["Description"] = origin + " - " + name
        para["Tracking"   ] = "minimal includelogs"
        if tag: para["Tag"] = tag
        if sign_key: para["SignWith"] = sign_key
        if pull_from and pull_from != code: para["Pull"] = "from-" + pull_from
        paras.append(para)
    (basedir / "conf/distributions").write_text('\n'.join(str(para) for para in paras))

def create_incoming(basedir, suites):
    codes=[]
    for suite, (code, tag, name) in suites.items():
        if suite == code: codes.append(code)
        else: codes.extend([suite + '>' + code, code])

    para = Deb822()
    para["Name"   ] = "changes"
    para["IncomingDir"] = "incoming"
    para["TempDir"] = "temp"
    para["Allow"  ] = ' '.join(codes)
    para["Options"] = "multiple_distributions"
    para["Cleanup"] = "on_deny on_error unused_buildinfo_files"
    (basedir / "conf/incoming").write_text(str(para))

def create_pulls(basedir, pull_from):
    para = Deb822()
    if pull_from:
        para["Name"] = "from-" + pull_from
        para["From"] = pull_from
        para["Architectures"] = "source"
    (basedir / "conf/pulls").write_text(str(para))

def create_sbuild(basedir):
    (basedir / ".config/sbuild").mkdir(parents=True, exist_ok=True)
    (basedir / ".config/sbuild/config.pl").write_text(f"""# config.pl

#$build_dep_resolver = "aptitude";
$build_environment = {{
    "CCACHE_DIR"        => "/build/ccache",
    "RUSTC_WRAPPER"     => "/usr/bin/sccache",
    "SCCACHE_DIR"       => "/build/sccache",
    "SCCACHE_BASEDIRS"  => "/build",
    "SCCACHE_IDLE_TIMEOUT" => "0",
}};
$check_space = 0;
$chroot_mode = "unshare";

$maintainer_name = 'micro-buildd <micro-buildd@noreply.me>';

$path = "/usr/lib/ccache:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games";
$run_lintian = 0;

$unshare_bind_mounts = [
    {{ directory => "{basedir}/.cache/ccache", mountpoint => "/build/ccache" }},
    {{ directory => "{basedir}/.cache/sccache", mountpoint => "/build/sccache" }},
    {{ directory => "{basedir}/archive", mountpoint => "/archive" }},
];

my @ubuntu_distros = split(/\\n/, `ubuntu-distro-info --supported`);
$unshare_mmdebstrap_extra_args = [
    "*" => [ "--verbose",
        "--customize-hook=chroot \\$1 update-ccache-symlinks",
        "--include=aptitude,ccache,sccache",
    ],
    map {{ $_ => [ "--components=main,universe" ] }} @ubuntu_distros,
];
$unshare_mmdebstrap_keep_tarball = 1;

1;
""")
    for name in [".cache/ccache", ".cache/sccache"]:
        (basedir / name).mkdir(parents=True, exist_ok=True)
        (basedir / name).chmod(0o777)

def create(basedir, origin, suites, arches, sign_key=None, pull_from=None):
    if not suites: suites = { code: (code, None) for code in [get_current_suite()] }
    if not arches: arches = { arch: arch for arch in [get_current_arch ()] }

    basedir.mkdir(parents=True, exist_ok=True)
    for name in ["archive", "archive/logs", "conf", "incoming", "temp"]:
        (basedir / name).mkdir(exist_ok=True)

    if sign_key:
        key = check_output(["gpg", "--export", "--armor", sign_key])
        if not key:
            print("* Key not found:", sign_key)
            sign_key = None
        else: (basedir / "archive/key.asc").write_bytes(key)

    temp = {}
    for suite, (code, tag) in suites.items():

        if suite == "debian" and code == "debian" and tag is None:
            aliases = { get_debian_code("stable"): "stable",
                get_debian_code("testing"): "testing", "sid": "unstable"
            }
            data = get_distro_data("debian")
            for code, (name, vers) in reversed(data.items()):
                if code == "rc-buggy": continue
                tag = None if code == "sid" else ("~deb" + vers)
                temp[aliases.get(code, code)] = (code, tag, name)

        elif suite == "ubuntu" and code == "ubuntu" and tag is None:
            data = get_distro_data("ubuntu")
            for code, (name, vers) in reversed(data.items()):
                temp[code] = (code, "~ubuntu" + vers, name)

        else: temp[suite] = (code, tag, code.capitalize())

    suites = temp
    if pull_from in suites: pull_from = suites[pull_from][0]

    create_distros(basedir, origin, suites, arches, sign_key, pull_from)
    create_incoming(basedir, suites)
    create_pulls(basedir, pull_from)
    create_sbuild(basedir)

    (basedir / "conf/options").write_text("""# options

ignore unknownfield
outdir +b/archive
silent
""")

    run(["reprepro", "export"], cwd=basedir)
    run(["reprepro", "createsymlinks"], cwd=basedir)
