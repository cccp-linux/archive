from debian.deb822 import Deb822
from os import environ
from shutil import copy, rmtree
from subprocess import check_output, run
from time import sleep

_INTERVAL = 15

def build_one(basedir, code, tag, arch, dsc, build):
    cmd = ["sbuild", "-q", "-d", code]
    if tag: cmd += (["--append-to-version", tag,
        # this makes binary packages with a tag refer to the source package with no tag
        "--starting-build-commands", "sed -i '1s/$/, binary-only=yes/' %p/debian/changelog"
    ])
    if arch == "all": cmd += ["--arch-all", "--no-arch-any"]
    else: cmd += ["--arch", arch, "--arch-any", "--no-arch-all"]

    key_file = basedir / "archive/key.asc"
    trust = "signed-by=/archive/key.asc" if key_file.exists() else "trusted=yes"
    cmd += ["--extra-repository", f"deb [{trust}] file:///archive {code} main"]

    cmd += [basedir / "archive" / dsc]

    print("* Building:", code, arch, dsc)
    run(cmd, env={**environ, "HOME": basedir}, cwd=build)

def build_needing(basedir, code, tag, failed):
    build = basedir / "build"

    out = check_output(["reprepro", "build-needing", code, "any"], cwd=basedir, text=True)
    for line in out.splitlines():
        name, vers, dsc, arch = line.split()
        if (code, name, vers, arch) in failed:
            print("* Skipping:", code, arch, dsc)
            continue

        rmtree(build, ignore_errors=True)
        build.mkdir()
        build_one(basedir, code, tag, arch, dsc, build)

        for changes in build.glob("*.changes"):
            log = changes.with_suffix(".build")
            if not log.exists() and (temp := next(build.glob("*[!Z].build"), None)):
                temp.rename(log)
            if log.exists(): run(["changestool", changes, "add", log], cwd=basedir)

            print("* Including:", changes.name)
            run(["reprepro", "include", code, changes], cwd=basedir)

        for temp in build.glob("*Z.build"): copy(temp, basedir / "archive/logs")

        temps = sorted((basedir / "archive/logs").glob("*Z.build"),
            key=lambda p: p.stat().st_mtime, reverse=True)
        for temp in temps[100:]: temp.unlink()

    failed = set()
    out = check_output(["reprepro", "build-needing", code, "any"], cwd=basedir, text=True)
    for line in out.splitlines():
        name, vers, _, arch = line.split()
        failed.add((code, name, vers, arch))
    return failed

def build_all(basedir):
    failed = basedir / "conf/failed"
    failed.touch()
    old_failed = set(tuple(line.split()) for line in failed.read_text().splitlines())

    new_failed = set()
    distros = basedir / "conf/distributions"
    with open(distros) as fp:
        for para in Deb822.iter_paragraphs(fp):
            new_failed |= build_needing(basedir, para["Codename"], para.get("Tag"), old_failed)

    failed.write_text("".join(" ".join(args) + '\n' for args in sorted(new_failed)))

def watch(basedir):
    build_all(basedir)

    incoming = basedir / "incoming"
    print("* Watching:", incoming)

    prev = {}
    while True:
        sizes = {}

        for path in incoming.glob("*.changes"):
            try: sizes[path] = path.stat().st_size
            except FileNotFoundError: pass

        for path, size in sizes.items():
            if prev.get(path) == size:
                changes = path.relative_to(incoming)

                print("* Processing:", changes)
                run(["reprepro", "processincoming", "changes", changes], cwd=basedir)
                run(["reprepro", "pull"], cwd=basedir)
                build_all(basedir)

        prev = sizes
        sleep(_INTERVAL)
