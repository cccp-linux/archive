# Micro-Build Daemon

micro-buildd is a very basic auto-builder for Debian packages.

## Installation

### Binary

Binary packages for Debian, Ubuntu, RaspberryPi and other Debian-based
distributions can be installed from the [CCCP Linux Package
Archive](https://github.com/cccp-linux/archive). Follow their instructions to
set up the archive and be sure to add the _dev_ component. Then, run:

```shell
sudo apt install micro-buildd
```

### From source

TODO

## Usage

TODO

Share and enjoy.

## Authors

* **Dimitry Ishenko** - dimitry (dot) ishenko (at) (gee) mail (dot) com

## License

This project is distributed under the GNU GPL license. See the
[LICENSE.md](LICENSE.md) file for details.
