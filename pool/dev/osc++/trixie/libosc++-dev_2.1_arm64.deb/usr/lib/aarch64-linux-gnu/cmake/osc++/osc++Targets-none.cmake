#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "osc++::osc++_shared" for configuration "None"
set_property(TARGET osc++::osc++_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(osc++::osc++_shared PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libosc++.so.2.1"
  IMPORTED_SONAME_NONE "libosc++.so.2"
  )

list(APPEND _cmake_import_check_targets osc++::osc++_shared )
list(APPEND _cmake_import_check_files_for_osc++::osc++_shared "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libosc++.so.2.1" )

# Import target "osc++::osc++_static" for configuration "None"
set_property(TARGET osc++::osc++_static APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(osc++::osc++_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "CXX"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libosc++.a"
  )

list(APPEND _cmake_import_check_targets osc++::osc++_static )
list(APPEND _cmake_import_check_files_for_osc++::osc++_static "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libosc++.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
