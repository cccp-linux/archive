#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "CEF::libcef_dll_wrapper" for configuration "Release"
set_property(TARGET CEF::libcef_dll_wrapper APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(CEF::libcef_dll_wrapper PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/cef/131/x86_64-linux-gnu/libcef_dll_wrapper.a"
  )

list(APPEND _cmake_import_check_targets CEF::libcef_dll_wrapper )
list(APPEND _cmake_import_check_files_for_CEF::libcef_dll_wrapper "${_IMPORT_PREFIX}/lib/cef/131/x86_64-linux-gnu/libcef_dll_wrapper.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
