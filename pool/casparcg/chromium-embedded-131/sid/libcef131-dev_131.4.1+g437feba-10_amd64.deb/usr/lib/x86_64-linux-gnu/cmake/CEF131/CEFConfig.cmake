include("${CMAKE_CURRENT_LIST_DIR}/CEFTargets.cmake")

add_library(CEF::CEF INTERFACE IMPORTED)
target_link_libraries(CEF::CEF INTERFACE CEF::libcef_dll_wrapper)
