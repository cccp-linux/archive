#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "GLEW::glew" for configuration "None"
set_property(TARGET GLEW::glew APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(GLEW::glew PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libGLEW.so.2.3.1"
  IMPORTED_SONAME_NONE "libGLEW.so.2.3"
  )

list(APPEND _cmake_import_check_targets GLEW::glew )
list(APPEND _cmake_import_check_files_for_GLEW::glew "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libGLEW.so.2.3.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
