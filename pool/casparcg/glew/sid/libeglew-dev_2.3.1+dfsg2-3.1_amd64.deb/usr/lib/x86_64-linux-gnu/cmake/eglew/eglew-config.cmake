# This config-module creates the following import libraries:
#
# - GLEW::eglew shared lib
# - GLEW::eglew_s static lib
#
# Additionally GLEW::GLEW will be created as an
# copy of either the shared (default) or the static libs.
#
# Dependending on the setting of BUILD_SHARED_LIBS at GLEW build time
# either the static or shared versions may not be available.
#
# Set GLEW_USE_STATIC_LIBS to OFF or ON to force using the shared
# or static lib for GLEW::GLEW 
#

include(${CMAKE_CURRENT_LIST_DIR}/eglew-targets.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/CopyImportedTargetProperties.cmake)

# decide which import library (eglew/eglew_s)
# needs to be copied to GLEW::GLEW
set(_eglew_target_postfix "")
set(_eglew_target_type SHARED)
if(DEFINED GLEW_USE_STATIC_LIBS)
  # if defined, use only static or shared
  if(GLEW_USE_STATIC_LIBS)
    set(_eglew_target_postfix "_s")
  endif()
  # else use static only if no shared
elseif(NOT TARGET GLEW::eglew AND TARGET GLEW::eglew_s)
  set(_eglew_target_postfix "_s")
endif()
if(_eglew_target_postfix STREQUAL "")
  set(_eglew_target_type SHARED)
else()
  set(_eglew_target_type STATIC)
endif()

# CMake doesn't allow creating ALIAS lib for an IMPORTED lib
# so create imported ones and copy the properties
foreach(_eglew_target eglew)
  set(_eglew_src_target "GLEW::${_eglew_target}${_eglew_target_postfix}")
  string(TOUPPER "GLEW::${_eglew_target}" _eglew_dest_target)
  if(TARGET ${_eglew_dest_target})
    get_target_property(_eglew_previous_src_target ${_eglew_dest_target}
      _GLEW_SRC_TARGET)
    if(NOT _eglew_previous_src_target STREQUAL _eglew_src_target)
      message(FATAL_ERROR "find_package(GLEW) was called the second time with "
        "different GLEW_USE_STATIC_LIBS setting. Previously, "
        "`eglew-config.cmake` created ${_eglew_dest_target} as a copy of "
        "${_eglew_previous_src_target}. Now it attempted to copy it from "
        "${_eglew_src_target}. ")
    endif()
  else()
    add_library(${_eglew_dest_target} ${_eglew_target_type} IMPORTED)
    # message(STATUS "add_library(${_eglew_dest_target} ${_eglew_target_type} IMPORTED)")
    copy_imported_target_properties(${_eglew_src_target} ${_eglew_dest_target})
    set_target_properties(${_eglew_dest_target} PROPERTIES
      _GLEW_SRC_TARGET ${_eglew_src_target})
  endif()
endforeach()
