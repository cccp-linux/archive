add_library(CEF::libcef SHARED IMPORTED)
set_target_properties(CEF::libcef PROPERTIES
  IMPORTED_LOCATION "/usr/lib/cef/x86_64-linux-gnu/150/libcef.so"
)

add_library(CEF::libcef_dll_wrapper STATIC IMPORTED)
set_target_properties(CEF::libcef_dll_wrapper PROPERTIES
  IMPORTED_LOCATION "/usr/lib/cef/x86_64-linux-gnu/150/libcef_dll_wrapper.a"
  IMPORTED_LINK_INTERFACE_LANGUAGES "CXX"
)
target_include_directories(CEF::libcef_dll_wrapper INTERFACE "/usr/lib/cef/x86_64-linux-gnu/150")
target_link_libraries(CEF::libcef_dll_wrapper INTERFACE CEF::libcef)
