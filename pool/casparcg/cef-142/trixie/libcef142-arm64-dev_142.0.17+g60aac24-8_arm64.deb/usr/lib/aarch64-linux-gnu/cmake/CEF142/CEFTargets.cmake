add_library(CEF::libcef SHARED IMPORTED)
set_target_properties(CEF::libcef PROPERTIES
  IMPORTED_LOCATION "/usr/lib/cef/aarch64-linux-gnu/142/libcef.so"
)
target_link_options(CEF::libcef INTERFACE "LINKER:-rpath,/usr/lib/cef/aarch64-linux-gnu/142")

add_library(CEF::libcef_dll_wrapper STATIC IMPORTED)
set_target_properties(CEF::libcef_dll_wrapper PROPERTIES
  IMPORTED_LOCATION "/usr/lib/cef/aarch64-linux-gnu/142/libcef_dll_wrapper.a"
  IMPORTED_LINK_INTERFACE_LANGUAGES "CXX"
)
target_include_directories(CEF::libcef_dll_wrapper INTERFACE "/usr/lib/cef/aarch64-linux-gnu/142")
target_link_libraries(CEF::libcef_dll_wrapper INTERFACE CEF::libcef)
