set(_cefapi_libdir "/usr/lib/cef/x86_64-linux-gnu/142")
cmake_path(GET _cefapi_libdir PARENT_PATH _cefapi_root)

foreach(api IN ITEMS 13300 13301 13302 13303 13304 13400 13401 13500 13600 13601 13700 13800 13900 14000 14100 14200)
  add_library(CEF::API${api} INTERFACE IMPORTED)
  target_compile_definitions(CEF::API${api} INTERFACE CEF_API_VERSION=${api})
  target_include_directories(CEF::API${api} INTERFACE "${_cefapi_libdir}")

  target_link_libraries(CEF::API${api} INTERFACE
    "${_cefapi_libdir}/api${api}/libcef_dll_wrapper.a"
    "${_cefapi_root}/api${api}/libcef.so"
  )
endforeach()

unset(_cefapi_libdir)
unset(_cefapi_root)
