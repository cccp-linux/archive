# .bash_aliases

alias ls="ls -FN --color=auto"
alias ll="ls -l"
alias la="ls -la"
alias lh="ls -lh"

alias installed="apt-mark showmanual"
alias nspawn="sudo systemd-nspawn --resolv-conf=bind-stub --timezone=off"
alias sl="sudo su --login"

export HISTCONTROL=ignoreboth
export NEWT_COLORS=root=black,black

if [[ -x $(command -v nvim) ]]; then
    export MANPAGER="nvim '+color vim' +Man!"
fi
