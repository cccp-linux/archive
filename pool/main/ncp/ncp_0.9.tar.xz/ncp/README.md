# ncp – New and Improved, Now Asbestos-Free Copy Utility

```help
Usage: ncp [option]... <SOURCE>... [DESTINATION]

Options:
-A, --acl              Preserve ACL (access control list).
-a, --archive          Archive mode (equivalent to -Dfmort).
-D                     Same as --special --devices.
    --devices          Preserve device files.
-f                     Same as --unlink=force.
-g, --group            Preserve group ownership.
-H, --hard-links       Preserve hard links.
-h, --help             Show this help message and exit.
-i, --interactive      Prompt before overwriting files.
-j, --jobs=<N>         Number of files to copy in parallel (max: 16).
-L, --follow-links     Dereference source symlinks (default when non-recursive).
-M, --move             Remove source files after copying.
-m, --mode             Preserve file permissions (mode bits).
-o, --ownership        Same as --user --group.
-P, --keep-links       Preserve source symlinks (default when recursive).
-p, --progress         Show progress bar.
-r, --recursive        Copy directories recursively.
    --special          Preserve named pipes and sockets.
-T, --target=<dir>     Target directory to copy into.
-t, --time             Preserve modification time.
-U                     Same as --update=older.
    --unlink=[when]    Unlink destination before writing. [when] can be one of:
                       'never', 'always', 'force' or 'auto'.
                       If [when] is omitted, 'always' is assumed.
                       If the option is omitted entirely, 'auto' is used.
    --update=[when]    Update existing files. [when] can be one of:
                       'none', 'all', 'older', 'changed' (size or time) or 'size'.
                       If [when] is omitted, 'older' is assumed.
                       If the option is omitted entirely, all files are updated,
                       which is equivalent to --update=all.
-u, --user             Preserve user ownership.
-V, --version          Show program version and exit.
-v, --verbose          Explain what is being done.

Parameters:
SOURCE                 Files or directories to copy or move.
DESTINATION            Destination file or directory.
```

## Installation

### Binary

Binary packages for Debian, Ubuntu, RaspberryPi and other Debian-based
distributions can be installed from the [CCCP Linux Package
Archive](https://github.com/cccp-linux/archive). Follow their instructions to
set up the archive and be sure to add the _main_ component. After that:

```shell
sudo apt install ncp
```

### From source

_TODO_

Share and enjoy.

## Authors

* **Dimitry Ishenko** - dimitry (dot) ishenko (at) (gee) mail (dot) com

## License

This project is distributed under the GNU GPL license. See the
[LICENSE.md](LICENSE.md) file for details.
