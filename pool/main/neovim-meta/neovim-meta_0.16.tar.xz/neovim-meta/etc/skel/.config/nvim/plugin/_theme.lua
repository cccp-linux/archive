require("gruvbox").setup({
    italic = { strings = false, comments = false }
})
vim.cmd("colorscheme gruvbox")
