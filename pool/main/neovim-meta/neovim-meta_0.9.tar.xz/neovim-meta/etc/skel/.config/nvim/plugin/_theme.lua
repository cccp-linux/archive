vim.cmd("colorscheme terafox")
