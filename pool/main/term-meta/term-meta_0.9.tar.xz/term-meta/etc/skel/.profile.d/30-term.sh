#!/bin/sh

# output_scale=1
# output_scale_eDP_1=2

if [ -z "$DISPLAY" -a -z "$WAYLAND_DISPLAY" ]; then
    case $(tty) in /dev/tty[3-6]) exec term tmux;; esac
fi
