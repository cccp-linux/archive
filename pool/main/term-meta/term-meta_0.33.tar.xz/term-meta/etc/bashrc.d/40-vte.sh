# 40-vte.sh

osc7_cwd()
{
    local c i
    printf '\e]7;file://'
    for ((i = 0; i < ${#PWD}; ++i)); do
        c=${PWD:$i:1}
        [[ "$c" == [-/:_.!\'\(\)~a-zA-Z0-9] ]] && printf '%s' "$c" || printf '%%%02X' "'$c"
    done
    printf '\e\\'
}
PROMPT_COMMAND=${PROMPT_COMMAND:+${PROMPT_COMMAND%;}; }osc7_cwd

prompt_mark() {
    printf '\e]133;A\e\\'
}
PROMPT_COMMAND=${PROMPT_COMMAND:+$PROMPT_COMMAND; }prompt_mark
