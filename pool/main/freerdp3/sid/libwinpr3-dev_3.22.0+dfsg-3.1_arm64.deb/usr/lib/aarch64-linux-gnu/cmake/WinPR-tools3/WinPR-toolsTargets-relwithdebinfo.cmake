#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "winpr-tools" for configuration "RelWithDebInfo"
set_property(TARGET winpr-tools APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(winpr-tools PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "winpr"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libwinpr-tools3.so.3.22.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libwinpr-tools3.so.3"
  )

list(APPEND _cmake_import_check_targets winpr-tools )
list(APPEND _cmake_import_check_files_for_winpr-tools "${_IMPORT_PREFIX}/lib/aarch64-linux-gnu/libwinpr-tools3.so.3.22.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
