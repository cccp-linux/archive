#ifndef WINPR_BUILD_FLAGS_H
#define WINPR_BUILD_FLAGS_H

#define WINPR_CFLAGS "-g -O2 -Werror=implicit-function-declaration -ffile-prefix-map=<src dir>=. -fstack-protector-strong -fstack-clash-protection -Wformat -Werror=format-security -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -D_TIME_BITS=64 -Wdate-time -D_FORTIFY_SOURCE=2 -DNDEBUG -D_LARGEFILE_SOURCE -D_FILE_OFFSET_BITS=64 -D_TIME_BITS=64 -Wdate-time -D_FORTIFY_SOURCE=2 -fvisibility=hidden -fno-omit-frame-pointer -Wredundant-decls -fsigned-char -Wimplicit-function-declaration -fvisibility=hidden -O2 -g -DNDEBUG"
#define WINPR_COMPILER_ID "GNU"
#define WINPR_COMPILER_VERSION "14.2.0"
#define WINPR_TARGET_ARCH "ARM"
#define WINPR_BUILD_CONFIG ""
#define WINPR_BUILD_TYPE "RelWithDebInfo"

#endif /* WINPR_BUILD_FLAGS_H */
