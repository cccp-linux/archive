#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "freerdp-shadow" for configuration "RelWithDebInfo"
set_property(TARGET freerdp-shadow APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(freerdp-shadow PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "freerdp;freerdp-server;winpr;winpr-tools"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libfreerdp-shadow3.so.3.21.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libfreerdp-shadow3.so.3"
  )

list(APPEND _cmake_import_check_targets freerdp-shadow )
list(APPEND _cmake_import_check_files_for_freerdp-shadow "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libfreerdp-shadow3.so.3.21.0" )

# Import target "freerdp-shadow-subsystem" for configuration "RelWithDebInfo"
set_property(TARGET freerdp-shadow-subsystem APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(freerdp-shadow-subsystem PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "freerdp;freerdp-server;winpr;winpr-tools;freerdp-shadow"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libfreerdp-shadow-subsystem3.so.3.21.0"
  IMPORTED_SONAME_RELWITHDEBINFO "libfreerdp-shadow-subsystem3.so.3"
  )

list(APPEND _cmake_import_check_targets freerdp-shadow-subsystem )
list(APPEND _cmake_import_check_files_for_freerdp-shadow-subsystem "${_IMPORT_PREFIX}/lib/arm-linux-gnueabihf/libfreerdp-shadow-subsystem3.so.3.21.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
