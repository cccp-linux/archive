#ifndef FREERDP_BUILD_CONFIG_H
#define FREERDP_BUILD_CONFIG_H

#define FREERDP_DATA_PATH "/usr/share/freerdp3"
#define FREERDP_KEYMAP_PATH ""
#define FREERDP_PLUGIN_PATH "lib/arm-linux-gnueabihf/freerdp3"

#define FREERDP_INSTALL_PREFIX "/usr"

#define FREERDP_LIBRARY_PATH "lib/arm-linux-gnueabihf"

#define FREERDP_ADDIN_PATH "lib/arm-linux-gnueabihf/freerdp3"

#define FREERDP_SHARED_LIBRARY_SUFFIX ".so"
#define FREERDP_SHARED_LIBRARY_PREFIX  "lib"

#define FREERDP_VENDOR_STRING "FreeRDP" /** @since version 3.3.0 */
#define FREERDP_PRODUCT_STRING "FreeRDP" /** @since version 3.3.0 */

#define FREERDP_PROXY_PLUGINDIR "lib/arm-linux-gnueabihf/freerdp3/proxy/" /** @since version 3.3.0 */

#endif /* FREERDP_BUILD_CONFIG_H */
